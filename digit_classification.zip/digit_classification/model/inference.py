import torch
import torchvision.transforms as transforms
import io
import os
from PIL import Image

from model.model import CNN

# Prediction Class
class DigitClassifier:
    def __init__(self, model_weights_filename="model.pt"):
        """Loads the trained model and prepares it for inference."""
        model_path = os.path.join(os.path.dirname(__file__), model_weights_filename)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = CNN().to(self.device)
        self.model.load_state_dict(torch.load(model_path, map_location=self.device))
        self.model.eval()  # Set to evaluation mode

        # Define transformation for input images
        self.transform = transforms.Compose([
            transforms.Grayscale(num_output_channels=1),  # Ensure grayscale
            transforms.Resize((28, 28)),  # Resize to MNIST size
            transforms.ToTensor(),
            transforms.Normalize((0.5,), (0.5,))
        ])

    def predict(self, file):
        """Predicts the digit for a given image."""
        # Load and preprocess the image
        image_bytes = file.read()
        image = Image.open(io.BytesIO(image_bytes))
        image = self.transform(image).unsqueeze(0).to(self.device)  # Add batch dimension

        # Get model prediction
        with torch.no_grad():
            output = self.model(image)
            _, predicted = torch.max(output, 1)

        return predicted.item()  # Return digit as integer