from flask import Flask, request, jsonify, render_template
import torch

from model.inference import DigitClassifier

app = Flask(__name__)

# Initialize and load the model once at startup
device = torch.device("cpu")
model_path = "model.pt"

digit_classification_model = DigitClassifier("./model.pt")

@app.route('/', methods=['GET'])
def home():
    # Rendering a template here
    print(type(render_template('./index.html') ))
    return render_template('./index.html')  # Serves the HTML form

@app.route('/api/v1/dc', methods=['POST'])
def dc_endpoint():
    """
    Endpoint that accepts an image file (e.g., in form-data)
    and returns the predicted digit.
    """
    if 'file' not in request.files:
        return jsonify({"error": "No file found"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # Inference
    prediction = digit_classification_model.predict(file)
    return jsonify({"prediction": prediction})

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "OK"}), 200

if __name__ == '__main__':
    # You can configure host/port as needed
    app.run(host='0.0.0.0', port=5001, debug=False)
